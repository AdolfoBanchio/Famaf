#ifndef TEST_PARSER_H
#define TEST_PARSER_H

#include <check.h>

Suite *parser_suite (void);

void parser_memory_test (void);

#endif
